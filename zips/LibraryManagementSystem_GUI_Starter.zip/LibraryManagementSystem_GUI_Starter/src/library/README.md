# Library Management System - Starter Code

## Requirements
- JDK 8 or later (JDK 11+ recommended)
- No external libraries or database required

## Package
All Java source files are in `src/library/` and use package `library`.

## Compile
From the project root:

```bash
javac -d out src/library/*.java
```

## Run

```bash
java -cp out library.Main
```

## Student implementation tasks

Complete the TODOs in the following order:

1. `LibraryManager.addItem`, `findItem`, `removeItem`, `searchByTitle`
2. `LibraryManager.addMember`, `findMember`
3. `LibraryManager.issueItem`, `countActiveLoans`, `returnItem`
4. `FileManager` integration and `LibraryManager.saveAll/loadAll`
5. `IssueTransaction` overdue-day and fine calculations
6. `Main.addSampleResources`
7. Add input validation and meaningful exception handling.

## Important design constraints

- Store resources as `ArrayList<LibraryItem>`.
- Use overridden `getLoanPeriod()` through a `LibraryItem` reference.
- Do not use repeated `instanceof` checks to determine loan periods.
- A member may have at most 3 active loans.
- Fine = Rs. 5 per overdue day.
- Do not remove a resource while it has an active issue transaction.
- Persist resources, members and transactions separately.
- Ensure resource availability and active transactions remain consistent.

## Suggested additional tests

- Duplicate IDs for resources and members.
- Unknown member/resource IDs.
- Issuing an already issued item.
- Attempting a fourth active loan.
- Returning an item against the wrong member.
- Returning an item twice.
- Restarting the program and verifying persistence.
- Returning an overdue item and checking its fine.

The starter methods intentionally contain TODOs. Students are expected to implement them.
