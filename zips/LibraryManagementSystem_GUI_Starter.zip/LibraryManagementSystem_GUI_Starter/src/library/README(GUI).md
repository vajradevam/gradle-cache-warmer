## Run the demo

```bash
javac -d out src/library/LibraryController.java src/library/DemoLibraryController.java src/library/LibraryGUI.java
java -cp out library.LibraryGUI
```

The demo is intentionally in-memory; it lets students explore the GUI without
having completed the backend. Data is lost when the program closes.

## Connect to the existing project
1. Copy `LibraryController.java`, `LibraryGUI.java`, and
   `LibraryManagerAdapter.java` into the existing `src/library` package.
2. Implement the six adapter methods using the actual method names in the
   students' `LibraryManager` and model classes.
3. Item rows must be: `ID, Type, Title, Author, Status`.
4. Active-loan rows must be: `Transaction ID, Member ID, Item ID, Due Date`.
5. In `LibraryGUI.main()`, replace the demo controller with:

```java
LibraryManager manager = new LibraryManager();
// Load persisted data here, if required by your implementation.
LibraryGUI gui = new LibraryGUI(new LibraryManagerAdapter(manager));
```

6. Compile all source files together:

```bash
javac -d out src/library/*.java
java -cp out library.LibraryGUI
```

## Included GUI operations
- View and search items
- Add Book, Magazine, or Journal
- Issue an item to a member
- Return an item by transaction ID
- View active loans

**Important:** Loan periods, maximum borrowing limit, overdue fines, validation,
and serialization must remain in the backend. Button listeners only collect
input, call the controller, and display results.